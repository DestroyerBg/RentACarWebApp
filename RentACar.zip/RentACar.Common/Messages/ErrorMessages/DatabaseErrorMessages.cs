﻿namespace RentACar.Common.Messages.ErrorMessages
{
    public static class DatabaseErrorMessages
    {
        public const string connectionStringNotAvailable = "Connection string is not available.";
    }
}
