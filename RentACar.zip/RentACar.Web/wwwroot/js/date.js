document.addEventListener("DOMContentLoaded", function () {
    flatpickr("#birthDate", {
        dateFormat: "d.m.Y",
        disableMobile: true
    });
});

document.addEventListener("DOMContentLoaded", function () {
    flatpickr("#startDate", {
        dateFormat: "d.m.Y",
        disableMobile: true
    });
});

document.addEventListener("DOMContentLoaded", function () {
    flatpickr("#endDate", {
        dateFormat: "d.m.Y",
        disableMobile: true
    });
});