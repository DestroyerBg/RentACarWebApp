﻿namespace RentACar.Core.Interfaces
{
    public interface IStringProvider
    {
        string GetConnectionString();
        string GetGeolocationApiKey();
    }
}
