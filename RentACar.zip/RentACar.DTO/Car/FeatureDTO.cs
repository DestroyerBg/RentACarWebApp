﻿namespace RentACar.DTO.Car
{
    public class FeatureDTO
    {
        public string Name { get; set; } = null!;
    }
}
