﻿namespace RentACar.DTO.Location
{
    public class OpenCageResultDTO
    {
        public string? Formatted { get; set; }
        public GeometryDTO? Geometry { get; set; }
    }
}