﻿namespace RentACar.DTO.Location
{
    public class GeometryDTO
    { 
        public double Lat { get; set; }
        public double Lng { get; set; }
    }
}