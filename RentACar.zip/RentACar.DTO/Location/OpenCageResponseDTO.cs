﻿namespace RentACar.DTO.Location
{
    public class OpenCageResponseDTO
    {
        public List<OpenCageResultDTO>? Results { get; set; }
    }

}
