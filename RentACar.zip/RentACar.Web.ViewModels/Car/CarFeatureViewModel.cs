﻿namespace RentACar.Web.ViewModels.Car
{
    public class CarFeatureViewModel
    {
        public string Name { get; set; } = null!;
    }
}
