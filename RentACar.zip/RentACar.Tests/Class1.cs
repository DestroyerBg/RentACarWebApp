﻿namespace RentACar.Tests
{
    public class Class1
    {

    }
}
